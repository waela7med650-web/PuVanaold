package com.example.watercustomers
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val area: String,
    val address: String,
    val location: String,
    val salesName: String,
    val salesPhone: String,
    val notes: String
)
