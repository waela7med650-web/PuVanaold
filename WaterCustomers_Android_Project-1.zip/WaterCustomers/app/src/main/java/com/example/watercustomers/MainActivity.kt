package com.example.watercustomers

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class CustomerViewModel(private val dao: CustomerDao) : ViewModel() {
    private val query = MutableStateFlow("")
    val customers = query.flatMapLatest { q ->
        if (q.isBlank()) dao.observeAll() else dao.search(q.trim())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun search(value: String) { query.value = value }
    fun save(customer: Customer) = viewModelScope.launch {
        if (customer.id == 0L) dao.insert(customer) else dao.update(customer)
    }
    fun delete(customer: Customer) = viewModelScope.launch { dao.delete(customer) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDatabase.get(this).customerDao()
        setContent { MaterialTheme { CustomerApp(remember { CustomerViewModel(dao) }) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerApp(vm: CustomerViewModel) {
    val customers by vm.customers.collectAsStateWithLifecycle()
    var query by remember { mutableStateOf("") }
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Customer?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("عملاء المياه") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showForm = true }) { Text("+") }
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it; vm.search(it) },
                label = { Text("ابحث بالاسم أو الرقم أو المنطقة") },
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            Text("عدد النتائج: ${customers.size}")
            Spacer(Modifier.height(8.dp))
            if (customers.isEmpty()) Text("لا توجد بيانات بعد. اضغط + لإضافة أول عميل.")
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(customers, key = { it.id }) { customer ->
                    CustomerCard(customer, { editing = customer; showForm = true }, { vm.delete(customer) })
                }
            }
        }
    }
    if (showForm) CustomerForm(editing, { showForm = false }, { vm.save(it); showForm = false })
}

@Composable
fun CustomerCard(customer: Customer, onEdit: () -> Unit, onDelete: () -> Unit) {
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(customer.name, style = MaterialTheme.typography.titleMedium)
            Text("الهاتف: ${customer.phone}")
            Text("المنطقة: ${customer.area}")
            Text("العنوان: ${customer.address}")
            if (customer.salesName.isNotBlank()) Text("المندوب: ${customer.salesName} — ${customer.salesPhone}")
            if (customer.notes.isNotBlank()) Text("ملاحظات: ${customer.notes}")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextButton(onClick = onEdit) { Text("تعديل") }
                TextButton(onClick = onDelete) { Text("حذف") }
                if (customer.location.isNotBlank()) TextButton(onClick = {
                    val url = if (customer.location.startsWith("http")) customer.location
                    else "https://www.google.com/maps/search/?api=1&query=${Uri.encode(customer.location)}"
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }) { Text("الخريطة") }
            }
        }
    }
}

@Composable
fun CustomerForm(initial: Customer?, onDismiss: () -> Unit, onSave: (Customer) -> Unit) {
    var name by remember(initial) { mutableStateOf(initial?.name ?: "") }
    var phone by remember(initial) { mutableStateOf(initial?.phone ?: "") }
    var area by remember(initial) { mutableStateOf(initial?.area ?: "") }
    var address by remember(initial) { mutableStateOf(initial?.address ?: "") }
    var location by remember(initial) { mutableStateOf(initial?.location ?: "") }
    var salesName by remember(initial) { mutableStateOf(initial?.salesName ?: "") }
    var salesPhone by remember(initial) { mutableStateOf(initial?.salesPhone ?: "") }
    var notes by remember(initial) { mutableStateOf(initial?.notes ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة عميل" else "تعديل بيانات العميل") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                Field("اسم العميل *", name) { name = it }
                Field("رقم هاتف العميل", phone) { phone = it }
                Field("المنطقة", area) { area = it }
                Field("العنوان بالتفصيل", address) { address = it }
                Field("رابط Google Maps", location) { location = it }
                Field("اسم مندوب المبيعات", salesName) { salesName = it }
                Field("رقم هاتف المندوب", salesPhone) { salesPhone = it }
                Field("ملاحظات إضافية", notes) { notes = it }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                onSave(Customer(
                    id = initial?.id ?: 0, name = name.trim(), phone = phone.trim(),
                    area = area.trim(), address = address.trim(), location = location.trim(),
                    salesName = salesName.trim(), salesPhone = salesPhone.trim(), notes = notes.trim()
                ))
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), singleLine = false
    )
}
